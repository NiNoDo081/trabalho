document.addEventListener('DOMContentLoaded', () => {
    const cartItems = [];
    const cartContainer = document.querySelector('.cart-items');
    const totalPriceElement = document.getElementById('total-price');

    function updateCart() {
        cartContainer.innerHTML = '';
        let totalPrice = 0;

        cartItems.forEach(item => {
            const li = document.createElement('li');
            li.innerHTML = `
                ${item.name} - R$ ${item.price}
                <button class="remove-from-cart-btn" data-name="${item.name}">Remover</button>
            `;
            cartContainer.appendChild(li);
            totalPrice += item.price;
        });

        totalPriceElement.textContent = totalPrice.toFixed(2);
    }

    document.querySelectorAll('.add-to-cart-btn').forEach(button => {
        button.addEventListener('click', () => {
            const name = button.getAttribute('data-product');
            const price = parseFloat(button.getAttribute('data-price'));

            cartItems.push({ name, price });
            updateCart();
        });
    });

    cartContainer.addEventListener('click', (e) => {
        if (e.target.classList.contains('remove-from-cart-btn')) {
            const name = e.target.getAttribute('data-name');
            const index = cartItems.findIndex(item => item.name === name);

            if (index !== -1) {
                cartItems.splice(index, 1);
                updateCart();
            }
        }
    });
});

// Adicione isso ao seu arquivo loja.js

document.addEventListener('DOMContentLoaded', () => {
    const checkoutBtn = document.getElementById('checkout-btn');
    const popup = document.getElementById('confirmation-popup');
    const closeBtn = document.querySelector('.close-btn');

    // Abre o popup quando o botão "Finalizar Compra" é clicado
    checkoutBtn.addEventListener('click', () => {
        popup.style.display = 'block';
    });

    // Fecha o popup quando o botão de fechar é clicado
    closeBtn.addEventListener('click', () => {
        popup.style.display = 'none';
    });

    // Fecha o popup quando se clica fora dele
    window.addEventListener('click', (event) => {
        if (event.target == popup) {
            popup.style.display = 'none';
        }
    });
});