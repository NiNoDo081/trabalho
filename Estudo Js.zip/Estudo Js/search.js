document.querySelector('.search-button').addEventListener('click', function() {
    var searchTerm = document.getElementById('searchBar').value.trim().toLowerCase();
    var produtos = document.querySelectorAll('.produto');
  
    produtos.forEach(function(produto) {
      var tituloProduto = produto.querySelector('.titulo-produto').textContent.trim().toLowerCase();
      if (tituloProduto.includes(searchTerm)) {
        produto.style.display = 'block';
      } else {
        produto.style.display = 'none';
      }
    });
  });